export default class BaseModel {
    id: string;
}