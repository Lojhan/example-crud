import DataModel from "./data.model";

export default class CalculatedDataModel extends DataModel {
    brute: number;
    irrf: number;
    inss: number;
    fgts: number;
    liquid: number;
}